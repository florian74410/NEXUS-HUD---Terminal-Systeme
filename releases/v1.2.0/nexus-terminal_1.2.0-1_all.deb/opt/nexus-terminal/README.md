# NEXUS Terminal 1.0.0 — NeonGlass Session Manager

- Fenêtre Qt sans barre de titre XFCE, contrôles hexagonaux.
- Paramètres / Connexions SSH, FTP, TCP, HTTP ; édition, suppression, test.
- Profil utilisateur Linux basé sur UID/pwd, enregistré sous ~/.config/nexus-terminal/connections.json (0600).
- SSH avec clés privées locales dans ~/.ssh ; jamais de copie de clés dans le profil.
- Sessions SSH partagées via tmux sur la machine distante ; même nom tmux pour les deux PC.
- FTP/TCP/HTTP : tests sortants, aucun serveur ni socket entrant lancé.
- La gestion des clés consiste à sélectionner une clé existante : la génération et l'autorisation des clés publiques restent à réaliser via ssh-keygen/ssh-copy-id.
- HTTP Web Inspector / proxy : **prévu ultérieurement**, non livré dans cette version.
- Dépendances Qt/PySide6 installées au premier lancement dans un environnement Python utilisateur.
- Aucune clé ni mot de passe stocké dans les préférences.

## Limites
Le paquet n'a pas été exécuté sur un bureau XFCE réel ici. Le terminal SSH requiert que tmux soit installé sur la cible et que la clé soit déjà autorisée. Le bouton Tester utilise un test synchrone (timeout 5 à 9 s) ; cela peut bloquer brièvement la popup. L'installation ne supprime pas arbitrairement les anciens dossiers de sources ni les données utilisateur.


## v1.1.0
- Suppression des entrées latérales Applications et Settings.
- Paramètres dans la barre supérieure : onglets Connexions et Mise à jour.
- Mise à jour par paquet Debian local ou manifeste HTTPS dans Update/stable.json.
- L'import direct ZIP est volontairement refusé : une archive non vérifiée ne doit pas exécuter de code.
- Le manifeste serveur n'est pas encore publié ; recherche distante indisponible tant qu'il manque.
- Le launcher Linux reste un exécutable Linux, pas un .exe Windows.

## v1.2.0 — GitHub Control (préversion)
- Menu clic droit sur QTermWidget : copier la sélection, coller, copier la page (si la bibliothèque expose le texte de l'écran), commandes Git.
- Paramètres → GitHub Fonctions : clé SSH, identité Git, chemins des dépôts, liste JSON de commandes personnalisables.
- Commandes par défaut : status, pull --ff-only, fetch --all --prune, push, log, pull all.
- Git Pull All applique pull --ff-only uniquement aux chemins de dépôts explicitement configurés ; confirmation et résultats affichés.
- Assistant : commande de génération ED25519 à exécuter dans un terminal pour saisir la passphrase, copie de clé publique et test SSH GitHub.
- Pas de stockage de token ; les tokens HTTPS doivent être conservés dans un gestionnaire de secrets système.
- Le contrôle des mises à jour via Update/stable.json est hérité de v1.1 ; le manifeste doit être publié et authentifié pour que le téléchargement fonctionne.
- Non testé graphiquement sous XFCE ; les actions Git sont synchrones et peuvent brièvement bloquer l'interface.
- La fonction « Copier la page » dépend des méthodes exposées par QTermWidget ; elle n'exporte pas encore tout le scrollback.
